La configuraci�n de openvpn en windows normalmente se encuentra en /Usuarios/<nombre user>/OpenVPN/config.  Se puede cambiar con el openvpn gui.

Falta .crt, .key de cliente

El cliente tiene un nombre de fichero ej: nombre1.crt, nombre1.key

Modificar en cliente.ovpn (fichero de configuraci�n) los campos cert y key.
ej:
cambiar 

cert nombre_cliente_a_modificar.crt
key nombre_cliente_a_modificar.key

por

cert nombre1.crt
key nombre1.key

